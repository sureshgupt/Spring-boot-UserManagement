package com.techouts.ppe.muser.email;

public interface EmailSender {
    void send(String to, String email);
}
