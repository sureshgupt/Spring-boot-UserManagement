package com.techouts.ppe.muser.model;

/**
 * Created by pavan on 11/11/20.
 */
public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
